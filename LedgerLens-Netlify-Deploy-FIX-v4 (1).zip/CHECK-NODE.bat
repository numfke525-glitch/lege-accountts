@echo off
setlocal
cd /d "%~dp0"
title LedgerLens - Node and npm Check
set "LOG=%~dp0NODE-CHECK-RESULT.txt"
>"%LOG%" echo LedgerLens Node.js and npm diagnostics
>>"%LOG%" echo --- Windows ---
ver >>"%LOG%" 2>&1
>>"%LOG%" echo --- Node Location ---
where node.exe >>"%LOG%" 2>&1
>>"%LOG%" echo --- Node Version ---
node -v >>"%LOG%" 2>&1
>>"%LOG%" echo --- npm Location ---
where npm.cmd >>"%LOG%" 2>&1
>>"%LOG%" echo --- npm Version ---
call npm.cmd -v >>"%LOG%" 2>&1
>>"%LOG%" echo --- Netlify CLI requirement ---
>>"%LOG%" echo Latest Netlify CLI requires Node >= 22.13.0.
type "%LOG%"
echo.
echo Check finished. Details saved to NODE-CHECK-RESULT.txt
pause
