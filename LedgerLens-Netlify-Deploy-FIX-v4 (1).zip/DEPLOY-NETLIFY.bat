@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title LedgerLens - Netlify Deploy FIX v4
set "LOG=%~dp0DEPLOY-DIAGNOSTIC.txt"
> "%LOG%" echo LedgerLens Netlify Deploy Diagnostics
>>"%LOG%" echo Windows version:
ver >>"%LOG%" 2>&1

echo =====================================================
echo            LedgerLens - NETLIFY DEPLOY FIX
 echo =====================================================
echo.
if not exist "netlify.toml" (
  echo [ERROR] netlify.toml not found. Extract ZIP fully first.
  goto fail
)

echo [1/6] Checking Node.js...
where node.exe >> "%LOG%" 2>&1
if errorlevel 1 goto missingnode
node --version >> "%LOG%" 2>&1
if errorlevel 1 goto brokennode
node --version
set "NODE_MAJOR="
set "NODE_MINOR="
for /f "tokens=1,2 delims=." %%A in ('node -p "process.versions.node"') do (
 set "NODE_MAJOR=%%A"
 set "NODE_MINOR=%%B"
)
if not defined NODE_MAJOR goto brokennode
if %NODE_MAJOR% LSS 22 goto oldnode
if %NODE_MAJOR% EQU 22 if %NODE_MINOR% LSS 13 goto oldnode

echo.
echo [2/6] Checking npm...
where npm.cmd >>"%LOG%" 2>&1
if errorlevel 1 goto brokennpm
call npm.cmd --version >>"%LOG%" 2>&1
if errorlevel 1 goto brokennpm
call npm.cmd --version

echo.
echo [3/6] Installing Netlify CLI (internet required)...
call npm.cmd install --no-save --no-package-lock netlify-cli@latest >>"%LOG%" 2>&1
if errorlevel 1 goto installfail
if not exist "node_modules\.bin\netlify.cmd" goto installfail
call "node_modules\.bin\netlify.cmd" --version
if errorlevel 1 goto installfail

echo.
echo [4/6] Opening Netlify login. Approve it in your browser.
call "node_modules\.bin\netlify.cmd" login
if errorlevel 1 goto fail

echo.
echo [5/6] Deploying site and functions...
echo On first deployment, choose your Netlify team and create or link a site.
call "node_modules\.bin\netlify.cmd" deploy --prod --dir=public --functions=netlify/functions
if errorlevel 1 goto fail

echo.
echo [6/6] Gemini API key setup:
echo 1. Open Netlify Dashboard for your deployed site.
echo 2. Project configuration / Environment variables / Add variable.
echo 3. Name: GEMINI_API_KEY
 echo 4. Value: a NEW secret key from Google AI Studio.
echo 5. Scopes: Functions or All scopes.
echo NEVER use the old key shared in chat.
echo.
choice /C YN /M "Have you added a NEW key in Netlify Dashboard and want to redeploy"
if errorlevel 2 goto incomplete
call "node_modules\.bin\netlify.cmd" deploy --prod --dir=public --functions=netlify/functions
if errorlevel 1 goto fail
 echo.
echo SUCCESS. Open the Production URL printed above.
echo Test with a clear small JPG photo of an accounting question.
echo.
pause
exit /b 0

:missingnode
echo [ERROR] Node.js was not found.
goto repair
:brokennode
echo [ERROR] node.exe exists but cannot run. Node.js may be damaged or incompatible with Windows.
goto repair
:oldnode
echo [ERROR] Netlify CLI latest needs Node.js version 22.13.0 or higher.
goto repair
:brokennpm
echo [ERROR] npm.cmd is missing or cannot execute. Repair Node.js installation.
goto repair
:repair
echo.
echo FIX: Install/repair a supported Node.js LTS from https://nodejs.org/en/download
 echo Close all CMD windows after installing, then run this BAT again.
echo If it still fails, open DEPLOY-DIAGNOSTIC.txt and send its text/screenshot.
goto fail
:installfail
echo [ERROR] Netlify CLI install failed. See DEPLOY-DIAGNOSTIC.txt
 echo Check internet connection, available disk space, and Node version.
goto fail
:incomplete
echo Site deployed, but AI photo solving will not work until a NEW GEMINI_API_KEY is configured.
echo Run this BAT again after saving the key to redeploy.
pause
exit /b 0
:fail
echo.
echo DEPLOY STOPPED. Details saved to:
echo %LOG%
echo Send a screenshot of this CMD window or the log (hide any secrets first).
pause
exit /b 1
